// script.js - Handles Chart.js Data Visualizations

document.addEventListener('DOMContentLoaded', function() {
    // ----------------------------------------------------
    // Chart 1: E-Waste Generation Trend in India
    // ----------------------------------------------------
    const genCtx = document.getElementById('generationChart').getContext('2d');
    
    // Data based on official CPCB reports, as referenced by Drishti IAS (Sept 2026)
    const generationData = {
        labels: ['2020-21', '2021-22', '2022-23', '2023-24', '2024-25'],
        datasets: [{
            label: 'E-Waste Generated (Lakh Tonnes)',
            data: [10.14, 11.21, 12.00, 12.54, 13.98], 
            backgroundColor: 'rgba(34, 197, 94, 0.2)', // Tailwind Green 500 with opacity
            borderColor: 'rgba(34, 197, 94, 1)',
            borderWidth: 2,
            tension: 0.3, // Curve the line slightly
            fill: true
        }]
    };

    new Chart(genCtx, {
        type: 'line',
        data: generationData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Lakh Tonnes'
                    }
                }
            }
        }
    });

    // ----------------------------------------------------
    // Chart 2: Composition of E-Waste in India
    // ----------------------------------------------------
    const compCtx = document.getElementById('compositionChart').getContext('2d');

    const compositionData = {
        labels: ['Computer Devices (70%)', 'Telecom Equipment (12%)', 'Electrical Equipment (8%)', 'Medical & Others (10%)'],
        datasets: [{
            data: [70, 12, 8, 10],
            backgroundColor: [
                '#3b82f6', // Blue
                '#10b981', // Green
                '#f59e0b', // Yellow
                '#ef4444'  // Red
            ],
            borderWidth: 1,
            hoverOffset: 4
        }]
    };

    new Chart(compCtx, {
        type: 'doughnut',
        data: compositionData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '%';
                        }
                    }
                }
            }
        }
    });
});

